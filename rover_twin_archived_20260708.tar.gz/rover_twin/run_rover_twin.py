"""
run_rover_twin.py — launch the ROS 2 "hardware twin" rover in a warehouse and let
Isaac's own graph drive the wheels from /cmd_vel. This is the sim half of the
twin; the ROS 2 half is launch/nav_twin.launch.py.

    isaacpy run_rover_twin.py                          # small warehouse, plain names
    isaacpy run_rover_twin.py --namespace sim_rover    # namespaced twin
    isaacpy run_rover_twin.py --env full_warehouse.usd --headless
    isaacpy run_rover_twin.py --ground-truth           # + /ground_truth/odom (metrics)

Unlike ugv_sim.py (which disables the graph's wheel output and drives through a
Python RoverDriveController so the keyboard can fight ROS 2), the twin lets the
ROS 2 graph own the wheels directly — that is what makes the sim rover respond to
/cmd_vel exactly like the hardware, so keyboard_ctrl / behavior_ctrl / the
lidar_* behaviors / Nav2 all drive it unchanged.

It builds the twin graph at load (on the referenced rover) rather than requiring a
pre-baked rover.usd, so it works whether or not you have run build_rover_usd.py.
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
ASSET_ROOT = SCRIPT_DIR.parent

REFERENCE_PRIM_PATH = "/World"
ROVER_PRIM_PATH = "/World/ugv_rover"
GRAPH_PATH = "/World/ActionGraph_ROS2_Drive"
ROVER_USD_NAME = "jetson_rover.usd"

PHYSICS_DT = 1.0 / 240.0
RENDERING_DT = 1.0 / 60.0


def _parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Run the ROS 2 twin rover in Isaac Sim.")
    p.add_argument("--env", default="small_warehouse.usd",
                   help="Environment USD (repo-root relative or absolute).")
    p.add_argument("--namespace", default="",
                   help="ROS namespace (default: empty = real-rover topic names).")
    p.add_argument("--rover", default=ROVER_USD_NAME,
                   help="Rover USD to compose (jetson_rover.usd or a baked rover.usd).")
    p.add_argument("--headless", action="store_true")
    p.add_argument("--lidar-debug-lines", action="store_true")
    p.add_argument("--no-camera", action="store_true")
    p.add_argument("--no-imu", action="store_true")
    p.add_argument("--ground-truth", action="store_true")
    return p.parse_args()


def _abs_asset(name: str) -> Path:
    path = Path(name).expanduser()
    return path if path.is_absolute() else (ASSET_ROOT / name)


def main() -> int:
    args = _parse_args()
    rover_usd = _abs_asset(args.rover).resolve()
    env_usd = _abs_asset(args.env).resolve()
    if not rover_usd.exists():
        raise FileNotFoundError(f"Rover USD not found: {rover_usd}")
    if not env_usd.exists():
        raise FileNotFoundError(f"Environment USD not found: {env_usd}")

    # ROS env before any Isaac/ROS import (mirrors ugv_sim._configure_ros_environment).
    os.environ.setdefault("ROS_DISTRO", "humble")
    os.environ.setdefault("ROS_DOMAIN_ID", "0")
    os.environ.setdefault("RMW_IMPLEMENTATION", "rmw_fastrtps_cpp")
    os.environ["ROS_LOCALHOST_ONLY"] = "0"

    if str(SCRIPT_DIR) not in sys.path:
        sys.path.insert(0, str(SCRIPT_DIR))

    from isaacsim import SimulationApp
    simulation_app = SimulationApp({"headless": args.headless})

    try:
        import rover_twin_graphs as twin
        twin.drive.enable_ros2_bridge_extensions()
        for _ in range(2):
            simulation_app.update()

        import omni.usd
        from isaacsim.core.api import World
        from isaacsim.core.utils.stage import add_reference_to_stage
        from pxr import UsdGeom

        if not omni.usd.get_context().open_stage(str(env_usd)):
            raise RuntimeError(f"Could not open environment USD: {env_usd}")
        for _ in range(5):
            simulation_app.update()

        stage = omni.usd.get_context().get_stage()
        if not stage.GetPrimAtPath("/World").IsValid():
            UsdGeom.Xform.Define(stage, "/World")

        add_reference_to_stage(usd_path=str(rover_usd), prim_path=REFERENCE_PRIM_PATH)
        for _ in range(5):
            simulation_app.update()

        world = World(physics_dt=PHYSICS_DT, rendering_dt=RENDERING_DT)

        # Author the full twin graph. ensure_ros2_drive_graph (inside build_twin)
        # removes any pre-existing graph at GRAPH_PATH first, so this is safe even
        # if the rover USD was baked with build_rover_usd.py.
        twin.build_twin(
            robot_prim_path=ROVER_PRIM_PATH,
            graph_path=GRAPH_PATH,
            namespace=args.namespace,
            enable_camera=not args.no_camera,
            enable_imu=not args.no_imu,
            enable_ground_truth=args.ground_truth,
            lidar_debug_lines=args.lidar_debug_lines,
        )

        world.reset()
        print("\n[run_rover_twin] Twin is live. Isaac's ROS 2 graph owns the wheels.\n"
              "  Drive it: ros2 launch rover_twin/launch/nav_twin.launch.py "
              f"{'namespace:=' + args.namespace + ' ' if args.namespace else ''}"
              "use_localization:=amcl use_localplan:=rpp\n")

        while simulation_app.is_running():
            world.step(render=not args.headless)
    finally:
        simulation_app.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
