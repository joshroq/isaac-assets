# rover_twin — Isaac Sim rover as a drop-in ROS 2 hardware twin

An **alternative** to the `ugv_controller` runners. Instead of a sim-only ROS
interface, the rover here exposes the **same ROS 2 contract as the real Waveshare
UGV** — same command topic, sensor topics, TF frames, odometry format — so every
existing `ugv_ws` consumer (keyboard_ctrl, behavior_ctrl, the `lidar_*` behaviors,
and Nav2 with any localizer/planner) drives the sim exactly as it drives hardware.

This folder is self-contained and does **not** modify anything under
`ugv_controller/` or `ugv_ws/`. It *reuses* the proven graph builders in
`ugv_controller/common/` rather than duplicating their node wiring.

## Files

| File | Role |
|---|---|
| `rover_twin_graphs.py` | The whole ROS 2 twin Action Graph, one namespace-aware `build_twin()`. Wraps `common/ros2_bridge_drive_graph.py` + `common/depth_camera_graph.py` and adds joint_states, lidar point cloud, IMU, ground-truth. |
| `build_rover_usd.py` | **Bakes** the graph into a standalone `rover.usd` (`isaacpy build_rover_usd.py`). This is the "graphs live in the USD" deliverable. |
| `run_rover_twin.py` | Isaac launcher: composes the rover into a warehouse and lets the graph drive the wheels from `/cmd_vel`. Works with or without a baked `rover.usd`. |
| `launch/nav_twin.launch.py` | ROS 2 side: the real rover's `ugv_nav` Nav2 stack verbatim + `robot_state_publisher`, with selectable `use_localization` / `use_localplan` / `use_slam` / `namespace`. |

## The topic/TF contract (namespace = "" → matches hardware byte-for-byte)

```
subscribes : /cmd_vel                       (geometry_msgs/Twist; x, yaw only)
publishes  : /clock                         (global — never namespaced)
             /odom                          (odom → base_footprint)
             /tf   odom→base_footprint      (dynamic; map→odom is the localizer's)
             /joint_states                  (all 6 wheels)
             /scan                          (base_lidar_link)
             /scan/points                   (lidar PointCloud2)
             /oak/rgb/image_rect            \
             /oak/rgb/camera_info            }  OAK-D-Lite emulation (RSD455)
             /oak/stereo/image_raw          /
             /imu/data                      (imu_link)
             /ground_truth/odom             (optional; THESIS METRICS ONLY)
```

Pass `--namespace sim_rover` to prefix every rover topic (`/sim_rover/...`) while
`/clock` stays global and TF frame *ids* stay plain — the layout Nav2 expects for
a namespaced robot.

## Run

```bash
# Terminal 1 — Isaac
isaacpy rover_twin/run_rover_twin.py                       # plain (real-rover) names
#   isaacpy rover_twin/run_rover_twin.py --namespace sim_rover
#   isaacpy rover_twin/build_rover_usd.py   # optional: bake graphs into rover.usd first

# Terminal 2 — ROS 2 (build + source ugv_ws first)
source /opt/ros/humble/setup.bash
source <repo>/ugv_ws/install/setup.bash
export ROS_DOMAIN_ID=0 RMW_IMPLEMENTATION=rmw_fastrtps_cpp
ros2 launch rover_twin/launch/nav_twin.launch.py use_localization:=amcl use_localplan:=rpp
```

Then in RViz send a **2D Nav Goal** → Nav2 plans → `/cmd_vel` → Isaac drives.
Drive `/cmd_vel` manually first when using a live-mapping localizer
(`use_slam:=true`). RGB-D / RTAB-Map and the visual-SLAM systems already have
shims under `ugv_controller/common/nav_systems/{nav_depth,nav_rgb,nav_dpvo,
nav_orbslam3}` — the twin publishes the same `/oak/*` topics, so they work
against it unchanged.

## Where I deviated from the pasted design spec (on purpose)

The design brief was sound in philosophy but its concrete names did **not** match
your actual rover. Following it literally would have produced a "twin" that is not
interchangeable with the hardware. Corrections:

| Pasted spec | Reality (used here) |
|---|---|
| frames `lidar_link`, `camera_link` | `base_lidar_link`, `3d_camera_link`, `oak_rgb_camera_optical_frame` (shared URDF) |
| `/oak/image_raw`, `/oak/camera_info`, `/oak/depth/image_raw` | `/oak/rgb/image_rect`, `/oak/rgb/camera_info`, `/oak/stereo/image_raw` (what `depth_camera_graph.py` + RTAB-Map actually use) |
| driven wheels front/rear, middle passive | driven = **corners** `left/right_up` + `left/right_down`; **middle** pair idles (`ros2_bridge_drive_graph.LEFT/RIGHT_WHEEL_JOINTS`) |
| Isaac publishes `tf_static` for base→sensors | `robot_state_publisher` (URDF) owns those, both real and sim — Isaac publishing them too would fight it |
| wrap `nav.launch.py`, add namespace passthrough | `nav.launch.py` starts **Gazebo** when `use_sim_time:=true`; the shim includes `nav2_bringup.launch.py` directly (which already supports namespace) |

## My opinion — is this change beneficial?

**Yes, the twin philosophy is the right long-term architecture, with one caveat.**

**Why it's worth doing**
- **One contract, many consumers.** Today `ugv_controller` is sim-first; making the
  sim expose the hardware's exact topics means keyboard/behavior/lidar-behavior
  nodes and *every* Nav2 localizer/planner run against sim and real with zero code
  changes. That is a genuine research multiplier for a sim-vs-real thesis.
- **It mostly *formalises* what you already built.** Your `nav_lidar`/`nav_depth`/
  `nav_rgb` shims already reuse the upstream stack and match hardware topic names.
  This just completes the contract (joint_states, point cloud, IMU, ground truth)
  and makes namespace a first-class knob. Low conceptual risk.
- **Ground-truth channel** (graph 16) gives you drift/accuracy metrics for free —
  ideal for the thesis comparison, as long as it never feeds Nav2/SLAM.

**The caveat — don't over-invest in simultaneous same-domain namespacing yet.**
The pasted design leans hard on running `/real_rover` and `/sim_rover` at once
under one ROS domain. That requires namespacing the *entire* upstream Nav2 stack
(and every AMCL/EMCL/cartographer/slam_toolbox sub-launch), remapping `/tf`
everywhere, and is exactly where multi-robot Nav2 setups usually break. Your own
`NAV_README` already recommends the cheaper, more robust path: **run sim and real
on different `ROS_DOMAIN_ID`s** with identical plain topic names. That gives you a
true twin (interchangeable consumers) for ~none of the namespacing risk. So:

- **Default here** = empty namespace + domain-ID isolation. Real twin, minimal risk.
- **Namespacing is wired in but optional** (`--namespace` / `use_namespace:=true`)
  for the day you genuinely need both robots live on one domain. Treat it as a
  later milestone to harden, not a prerequisite.

**Net:** build the twin (this folder), keep the graphs baked into `rover.usd` so
the asset is self-describing, standardise on the hardware topic names, and reach
for namespacing only when a specific experiment demands both robots on one domain.
The one thing I would *not* do is chase full same-domain multi-robot Nav2 up front
— the payoff is small next to the integration cost.

## Runtime-iteration flags (need a live Isaac session to confirm)

These follow the same "flag it, tune on first run" spirit as `NAV_README.md`:

1. **IMU / point-cloud node type names** — `_add_imu` uses
   `isaacsim.sensors.physics.IsaacReadIMU` and `_add_lidar_pointcloud` uses
   `ROS2RtxLidarHelper type=point_cloud`. Confirm these node ids on your Isaac Sim
   version; adjust in `rover_twin_graphs.py` if they moved.
2. **IMU prim discovery** — `_add_imu` searches for an `IsaacImuSensor` prim under
   the rover; if the rover USD has none, `/imu/data` is silently skipped (the
   lidar/Nav2 stack does not need it). Add an IMU sensor prim to enable it.
3. **Baked prim path** — `build_rover_usd.py` writes the graph against the USD's
   default prim (`/ugv_rover` when opened directly). If your rover USD nests the
   articulation differently, pass `--robot-prim /Your/Path`.
4. **Wheel output ownership** — unlike `ugv_sim.py`, the twin lets the ROS 2 graph
   drive the wheels directly (no Python `RoverDriveController`, no keyboard
   fight). If you want keyboard override back, port `set_wheel_output_enabled`
   from `ros2_bridge_drive_graph.py`.
5. **Scan orientation** — same as the existing systems: if `/scan` looks rotated,
   fix the lidar prim's local frame in the USD, never add a compensating TF.
```
