"""
build_rover_usd.py — bake the ROS 2 twin Action Graph INTO a standalone
``rover.usd`` so the graphs travel with the asset (the user's goal: "a rover.usd
file [that] will have the graphs to output and input ros2 commands").

    isaacpy build_rover_usd.py                       # -> rover.usd, no namespace
    isaacpy build_rover_usd.py --namespace sim_rover # -> namespaced twin
    isaacpy build_rover_usd.py --source jetson_rover.usd --out rover.usd

It opens the existing ``jetson_rover.usd`` directly as the stage (so its default
prim, sensors and physics are all present), authors the twin graph onto that
prim with rover_twin_graphs.build_twin(), and Save-As the result.

Then run it with run_rover_twin.py (which references rover.usd into a warehouse
and just presses Play — no runtime graph building needed).

RUNTIME-ITERATION FLAG: when a rover USD is *opened directly* its articulation
root is the file's default prim (typically ``/ugv_rover``), NOT the
``/World/ugv_rover`` path it takes once referenced into a scene. This script
detects the default prim automatically; if your USD nests it differently, pass
``--robot-prim /Your/Path``.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
ASSET_ROOT = SCRIPT_DIR.parent  # repo root holds jetson_rover.usd / *_warehouse.usd


def _parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Bake the ROS 2 twin graph into rover.usd")
    p.add_argument("--source", default=str(ASSET_ROOT / "jetson_rover.usd"),
                   help="Source rover USD to add the graph to.")
    p.add_argument("--out", default=str(ASSET_ROOT / "rover.usd"),
                   help="Output USD to write (default: <repo>/rover.usd).")
    p.add_argument("--namespace", default="",
                   help="ROS namespace to bake in (default: empty = real-rover names).")
    p.add_argument("--robot-prim", default="",
                   help="Override the rover articulation prim path (default: the USD's default prim).")
    p.add_argument("--no-camera", action="store_true")
    p.add_argument("--no-imu", action="store_true")
    p.add_argument("--no-pointcloud", action="store_true")
    p.add_argument("--ground-truth", action="store_true")
    return p.parse_args()


def main() -> int:
    args = _parse_args()
    source = Path(args.source).expanduser().resolve()
    out = Path(args.out).expanduser().resolve()
    if not source.exists():
        raise FileNotFoundError(f"Source rover USD not found: {source}")

    if str(SCRIPT_DIR) not in sys.path:
        sys.path.insert(0, str(SCRIPT_DIR))

    from isaacsim import SimulationApp
    simulation_app = SimulationApp({"headless": True})

    try:
        import rover_twin_graphs as twin
        twin.drive.enable_ros2_bridge_extensions()
        for _ in range(2):
            simulation_app.update()

        import omni.usd
        if not omni.usd.get_context().open_stage(str(source)):
            raise RuntimeError(f"Could not open source USD: {source}")
        for _ in range(5):
            simulation_app.update()

        stage = omni.usd.get_context().get_stage()
        robot_prim = args.robot_prim or (
            stage.GetDefaultPrim().GetPath().pathString
            if stage.GetDefaultPrim() else "/ugv_rover"
        )
        # The graph is authored as a sibling of the rover so it saves into this layer.
        graph_path = "/ActionGraph_ROS2_Drive"

        twin.build_twin(
            robot_prim_path=robot_prim,
            graph_path=graph_path,
            namespace=args.namespace,
            enable_camera=not args.no_camera,
            enable_imu=not args.no_imu,
            enable_pointcloud=not args.no_pointcloud,
            enable_ground_truth=args.ground_truth,
        )
        for _ in range(2):
            simulation_app.update()

        omni.usd.get_context().save_as_stage(str(out))
        print(f"\n[build_rover_usd] Baked twin graph into: {out}\n"
              f"  source robot prim: {robot_prim}\n"
              f"  namespace:         {args.namespace or '(none)'}\n"
              f"  Run it with:       isaacpy run_rover_twin.py")
    finally:
        simulation_app.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
