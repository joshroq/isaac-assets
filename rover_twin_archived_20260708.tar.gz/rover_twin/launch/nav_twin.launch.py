"""nav_twin.launch.py — ROS 2 side of the Isaac "hardware twin".

Generalises the proven isaac_nav_lidar.launch.py: instead of forcing lidar-only
slam_toolbox (use_slam:=True), it exposes the SAME selectors the real rover's
nav.launch.py has, so you choose the localizer that matches what the twin is
publishing, and the planner:

    use_localization : amcl | emcl | cartographer | slam_toolbox   (map->odom source)
    use_slam         : true = build the map live; false = localize on a saved map
    use_localplan    : teb | dwa | rpp | mppi                      (controller)

It brings up the real rover's Nav2 stack VERBATIM (ugv_nav
nav_bringup/nav2_bringup.launch.py) plus robot_state_publisher from the rover
URDF (the static base/sensor TFs). ONLY the hardware/Gazebo bringup is left out —
Isaac already publishes /scan, /odom, odom->base_footprint, /oak/* and consumes
/cmd_vel. This deliberately AVOIDS upstream nav.launch.py, which would start
Gazebo whenever use_sim_time:=true.

For RGB-D / RTAB-Map and the visual-SLAM systems (map->odom from camera), use the
existing ugv_controller/common/nav_systems/{nav_depth,nav_rgb,nav_dpvo,
nav_orbslam3} shims — the twin publishes the same /oak topics they expect, so they
work against it unchanged.

Equivalence to the real rover:
    real:  ros2 launch ugv_nav nav.launch.py use_localization:=amcl use_localplan:=rpp
    twin:  ros2 launch rover_twin/launch/nav_twin.launch.py use_localization:=amcl use_localplan:=rpp

PREREQUISITES (build + source ugv_ws so ugv_nav/ugv_slam are on the ament path):
    cd <repo>/ugv_ws && colcon build --packages-select ugv_nav ugv_slam --symlink-install
    source install/setup.bash
    # apt: ros-humble-navigation2 ros-humble-nav2-bringup ros-humble-slam-toolbox

RUN (with run_rover_twin.py already running in Isaac):
    source /opt/ros/humble/setup.bash
    source <repo>/ugv_ws/install/setup.bash
    export ROS_DOMAIN_ID=0 RMW_IMPLEMENTATION=rmw_fastrtps_cpp
    ros2 launch rover_twin/launch/nav_twin.launch.py use_localization:=amcl use_localplan:=rpp
    # live lidar mapping instead of a saved map:
    ros2 launch rover_twin/launch/nav_twin.launch.py use_localization:=slam_toolbox use_slam:=true
    # simultaneous with the real rover on one domain (namespaced, /tf isolated):
    ros2 launch rover_twin/launch/nav_twin.launch.py namespace:=sim_rover use_namespace:=true
"""

import os
import tempfile
import yaml

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, OpaqueFunction
from launch.conditions import IfCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node

# The URDF lives in the (unbuilt) ugv_ws source tree; read it by absolute path and
# rewrite package:// mesh URIs to file:// so robot_state_publisher needs no install.
UGV_WS_SRC = "/home/joshroq/projects/isaac-assets/ugv_ws/src/ugv_main"
UGV_DESCRIPTION_SRC = os.path.join(UGV_WS_SRC, "ugv_description")
URDF_PATH = os.path.join(UGV_DESCRIPTION_SRC, "urdf", "ugv_rover.urdf")

_LOCALPLAN_CHOICES = ("teb", "dwa", "rpp", "mppi")
_LOCALIZATION_CHOICES = ("amcl", "emcl", "cartographer", "slam_toolbox")


def _load_robot_description() -> str:
    if not os.path.isfile(URDF_PATH):
        raise RuntimeError(f"Isaac rover URDF not found: {URDF_PATH}")
    with open(URDF_PATH, "r") as f:
        robot_description = f.read()
    mesh_root = "file://" + UGV_DESCRIPTION_SRC.rstrip("/") + "/"
    return robot_description.replace("package://ugv_description/", mesh_root)


def _require_file(path: str, label: str) -> str:
    if not os.path.isfile(path):
        raise RuntimeError(f"{label} not found: {path}")
    return path


def _launch_value(context, name: str, default: str) -> str:
    value = context.launch_configurations.get(name, default)
    return default if value == "" else value


def _launch_bool(context, name: str, default: bool = False) -> bool:
    value = str(context.launch_configurations.get(name, str(default))).strip().lower()
    return value in ("1", "true", "yes", "on")


def _drop_filter(params: dict, filter_name: str) -> None:
    filters = params.get("filters")
    if isinstance(filters, list) and filter_name in filters:
        params["filters"] = [item for item in filters if item != filter_name]
        if not params["filters"]:
            params.pop("filters", None)
    params.pop(filter_name, None)


def _write_params_for_enabled_filters(source_file, keepout_enabled, speed_enabled) -> str:
    """Strip disabled keepout/speed costmap filters (same shim as isaac_nav_lidar)."""
    with open(source_file, "r") as f:
        data = yaml.safe_load(f)
    for outer, inner in (("local_costmap", "local_costmap"), ("global_costmap", "global_costmap")):
        params = data.get(outer, {}).get(inner, {}).get("ros__parameters", {})
        if not keepout_enabled:
            _drop_filter(params, "keepout_filter")
        if not speed_enabled:
            _drop_filter(params, "speed_filter")
    if not keepout_enabled:
        data.pop("keepout_filter_mask_server", None)
        data.pop("keepout_costmap_filter_info_server", None)
    if not speed_enabled:
        data.pop("speed_filter_mask_server", None)
        data.pop("speed_costmap_filter_info_server", None)
    fd, path = tempfile.mkstemp(prefix="nav_twin_", suffix=".yaml")
    with os.fdopen(fd, "w") as f:
        yaml.safe_dump(data, f, sort_keys=False)
    return path


def _launch_setup(context, *args, **kwargs):
    ugv_nav_dir = get_package_share_directory("ugv_nav")
    nav_bringup = _require_file(
        os.path.join(ugv_nav_dir, "launch", "nav_bringup", "nav2_bringup.launch.py"),
        "ugv_nav nav2 bringup launch",
    )

    namespace = LaunchConfiguration("namespace")
    use_namespace = LaunchConfiguration("use_namespace")
    use_sim_time = LaunchConfiguration("use_sim_time")
    use_slam = LaunchConfiguration("use_slam")
    autostart = LaunchConfiguration("autostart")
    use_composition = LaunchConfiguration("use_composition")
    use_respawn = LaunchConfiguration("use_respawn")
    use_rviz = LaunchConfiguration("use_rviz")
    log_level = LaunchConfiguration("log_level")
    use_keepout_zones = LaunchConfiguration("use_keepout_zones")
    use_speed_zones = LaunchConfiguration("use_speed_zones")

    localization = context.launch_configurations.get("use_localization", "amcl")
    if localization not in _LOCALIZATION_CHOICES:
        raise RuntimeError(
            f"use_localization must be one of {_LOCALIZATION_CHOICES} (RTAB-Map / visual "
            f"systems use the nav_depth/nav_rgb/nav_dpvo/nav_orbslam3 shims), got '{localization}'"
        )
    localplan = context.launch_configurations.get("use_localplan", "rpp")
    if localplan not in _LOCALPLAN_CHOICES:
        raise RuntimeError(f"use_localplan must be one of {_LOCALPLAN_CHOICES}, got '{localplan}'")

    params_file = _require_file(
        os.path.join(ugv_nav_dir, "params", f"{localplan}.yaml"), f"ugv_nav {localplan} params"
    )
    keepout_enabled = _launch_bool(context, "use_keepout_zones")
    speed_enabled = _launch_bool(context, "use_speed_zones")

    map_yaml = _launch_value(context, "map", os.path.join(ugv_nav_dir, "maps", "map.yaml"))
    pbstream = _launch_value(context, "pbstream", os.path.join(ugv_nav_dir, "maps", "map.pbstream"))
    posegraph = _launch_value(context, "posegraph", os.path.join(ugv_nav_dir, "maps", "map"))
    keepout_mask = _launch_value(context, "keepout_mask", os.path.join(ugv_nav_dir, "maps", "mask.yaml"))
    speed_mask = _launch_value(context, "speed_mask", "")
    emcl2_params_file = _launch_value(
        context, "emcl2_params_file", os.path.join(ugv_nav_dir, "params", "emcl2_quick_start.param.yaml")
    )
    slam_toolbox_params_file = _launch_value(
        context, "slam_toolbox_params_file",
        os.path.join(ugv_nav_dir, "params", "slam_toolbox_localization.yaml"),
    )

    _require_file(map_yaml, "ugv_nav map yaml")
    if speed_enabled and not speed_mask:
        raise RuntimeError("use_speed_zones:=True requires speed_mask:=/path/to/speed_mask.yaml")
    params_file = _write_params_for_enabled_filters(params_file, keepout_enabled, speed_enabled)

    robot_state_publisher = Node(
        package="robot_state_publisher",
        executable="robot_state_publisher",
        parameters=[{"use_sim_time": use_sim_time, "robot_description": _load_robot_description()}],
        output="screen",
    )

    nav2 = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(nav_bringup),
        launch_arguments={
            "namespace": namespace,
            "use_namespace": use_namespace,
            "use_slam": use_slam,
            "use_sim_time": use_sim_time,
            "use_localization": localization,
            "params_file": params_file,
            "slam_toolbox_params_file": slam_toolbox_params_file,
            "map": map_yaml,
            "pbstream": pbstream,
            "posegraph": posegraph,
            "keepout_mask": keepout_mask,
            "speed_mask": speed_mask,
            "emcl2_params_file": emcl2_params_file,
            "autostart": autostart,
            "use_composition": use_composition,
            "use_respawn": use_respawn,
            "log_level": log_level,
            "use_keepout_zones": use_keepout_zones,
            "use_speed_zones": use_speed_zones,
        }.items(),
    )

    rviz_config = _launch_value(
        context, "rviz_config", os.path.join(ugv_nav_dir, "rviz", "view_nav_2d.rviz")
    )
    rviz = Node(
        condition=IfCondition(use_rviz),
        package="rviz2", executable="rviz2", name="rviz2",
        arguments=["-d", rviz_config],
        parameters=[{"use_sim_time": use_sim_time}],
        output="screen",
    )

    # robot_pose_publisher — same as the real rover, so behavior_ctrl's /robot_pose works.
    robot_pose_publisher = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(get_package_share_directory("robot_pose_publisher"),
                         "launch", "robot_pose_publisher_launch.py")
        ),
    )

    return [robot_state_publisher, nav2, robot_pose_publisher, rviz]


def generate_launch_description():
    return LaunchDescription([
        DeclareLaunchArgument("namespace", default_value="",
                              description="Top-level namespace (e.g. sim_rover)"),
        DeclareLaunchArgument("use_namespace", default_value="false",
                              description="Apply namespace to the Nav2 stack + isolate /tf"),
        DeclareLaunchArgument("use_sim_time", default_value="true",
                              description="Use the /clock published by Isaac Sim"),
        DeclareLaunchArgument("use_slam", default_value="false",
                              description="true = map live (slam_toolbox/cartographer); false = localize on saved map"),
        DeclareLaunchArgument("use_localization", default_value="amcl",
                              description="amcl | emcl | cartographer | slam_toolbox "
                                          "(RTAB-Map/visual use the nav_depth/nav_rgb/... shims)"),
        DeclareLaunchArgument("use_localplan", default_value="rpp",
                              description="Nav2 local planner: teb | dwa | rpp | mppi"),
        DeclareLaunchArgument("map", default_value=""),
        DeclareLaunchArgument("pbstream", default_value=""),
        DeclareLaunchArgument("posegraph", default_value=""),
        DeclareLaunchArgument("keepout_mask", default_value=""),
        DeclareLaunchArgument("speed_mask", default_value=""),
        DeclareLaunchArgument("emcl2_params_file", default_value=""),
        DeclareLaunchArgument("slam_toolbox_params_file", default_value=""),
        DeclareLaunchArgument("rviz_config", default_value=""),
        DeclareLaunchArgument("autostart", default_value="true"),
        DeclareLaunchArgument("use_composition", default_value="True"),
        DeclareLaunchArgument("use_respawn", default_value="False"),
        DeclareLaunchArgument("log_level", default_value="info"),
        DeclareLaunchArgument("use_keepout_zones", default_value="False"),
        DeclareLaunchArgument("use_speed_zones", default_value="False"),
        DeclareLaunchArgument("use_rviz", default_value="true"),
        OpaqueFunction(function=_launch_setup),
    ])
