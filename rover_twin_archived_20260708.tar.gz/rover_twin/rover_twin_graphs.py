"""
rover_twin_graphs.py — the complete ROS 2 "hardware twin" Action Graph for the
Isaac Sim rover, authored as ONE parametrised builder that can be baked into
``rover.usd``.

GOAL
----
Make the simulated rover a DROP-IN ROS 2 twin of the real Waveshare UGV: it must
expose the *same* command topic, sensor topics, TF frames and odometry format as
the hardware, so every existing ugv_ws consumer (keyboard_ctrl, behavior_ctrl,
lidar_follow / lidar_guard / lidar_obstacle_avoidance, and Nav2 with any
localizer) drives the sim exactly as it drives the real robot.

This module is a THIN, namespace-aware orchestrator on top of the already
battle-tested builders in ``ugv_controller/common``:

    ros2_bridge_drive_graph.py   context+clock+cmd_vel+diff-drive+articulation,
                                 odom+raw TF (odom->base_footprint), lidar /scan,
                                 lidar/camera prim finders
    depth_camera_graph.py        /oak RGB-D publishers (RSD455 -> OAK-D-Lite)

On top of those it adds the graphs that a full twin needs but the lidar/RTAB-Map
runners never required:

    06  /joint_states       (all six wheels, incl. the two idler middles)
    11  /scan/points        lidar point cloud (collision-monitor / 3D consumers)
    14  /imu/data           IMU (for robot_localization / VI-SLAM later)
    16  /ground_truth/odom  Isaac world-truth pose (THESIS METRICS ONLY)

Everything is parametrised by ``namespace`` (default ``""`` -> plain topic names
that match the real rover byte-for-byte). Passing ``namespace="sim_rover"``
prefixes every rover topic (``/sim_rover/cmd_vel`` ...) while /clock stays global
and TF frame *ids* stay plain (map, odom, base_footprint, base_lidar_link, ...) —
the practical layout Nav2 expects for a namespaced robot.

CONTRACT (namespace="" shown; add /<ns> in front of each rover topic otherwise)
    subscribes:  /cmd_vel
    publishes:   /clock (global)  /odom  /joint_states  /tf (odom->base_footprint)
                 /scan  /scan/points  /oak/rgb/image_rect  /oak/rgb/camera_info
                 /oak/stereo/image_raw  /imu/data  (/ground_truth/odom optional)

Static base_link->sensor/wheel TFs are intentionally NOT published here: the real
rover gets them from robot_state_publisher (URDF), and the ugv_ws nav launches
already start it. Duplicating them in Isaac would fight that publisher. map->odom
is likewise owned by the selected localizer (slam_toolbox / AMCL / EMCL /
cartographer / RTAB-Map), never by the sim.
"""

from __future__ import annotations

import sys
from pathlib import Path

# The proven builders live in ugv_controller/common. Add it to the path so a baked
# rover.usd twin reuses the exact node wiring the lidar / RTAB-Map systems use.
_COMMON_DIR = (
    Path(__file__).resolve().parent.parent
    / "ugv_controller" / "common"
)
if str(_COMMON_DIR) not in sys.path:
    sys.path.insert(0, str(_COMMON_DIR))

import ros2_bridge_drive_graph as drive  # noqa: E402
import depth_camera_graph as depthcam    # noqa: E402


# One graph holds the whole twin, matching the existing runner's convention so
# keyboard-override wheel toggling (drive.set_wheel_output_enabled) still works.
DEFAULT_GRAPH_PATH = "/World/ActionGraph_ROS2_Drive"
DEFAULT_ROBOT_PRIM_PATH = "/World/ugv_rover"

# All six wheels publish joint states even though only the four corners are driven
# (drive.LEFT_WHEEL_JOINTS + drive.RIGHT_WHEEL_JOINTS). The middles are free idlers.
MIDDLE_WHEEL_JOINTS = ["left_middle_wheel_link_joint", "right_middle_wheel_link_joint"]
ALL_WHEEL_JOINTS = (
    drive.LEFT_WHEEL_JOINTS + drive.RIGHT_WHEEL_JOINTS + MIDDLE_WHEEL_JOINTS
)

# Frame ids — the REAL rover's names (shared URDF). Do not rename to the generic
# lidar_link / camera_link: the ugv_ws launches and RTAB-Map remaps use these.
IMU_FRAME_ID = "imu_link"
LIDAR_FRAME_ID = drive.LIDAR_FRAME_ID          # base_lidar_link
ODOM_FRAME_ID = drive.ODOM_FRAME_ID            # odom
BASE_FRAME_ID = drive.BASE_FRAME_ID            # base_footprint


def _ns(namespace: str, topic: str) -> str:
    """Prefix a rover topic with the namespace (``""`` -> unchanged, real-rover names)."""
    namespace = (namespace or "").strip().strip("/")
    if not namespace:
        return topic
    return f"/{namespace}{topic}"


def build_twin(
    robot_prim_path: str = DEFAULT_ROBOT_PRIM_PATH,
    graph_path: str = DEFAULT_GRAPH_PATH,
    namespace: str = "",
    ros_domain_id: int = 0,
    enable_camera: bool = True,
    enable_imu: bool = True,
    enable_pointcloud: bool = True,
    enable_ground_truth: bool = False,
    lidar_debug_lines: bool = False,
) -> None:
    """
    Author the full ROS 2 twin graph onto ``robot_prim_path``.

    Safe to call once and then Save-As ``rover.usd`` (see build_rover_usd.py), or
    at runtime before ``sim.play()`` (see run_rover_twin.py). Extensions must be
    enabled first via drive.enable_ros2_bridge_extensions().
    """
    drive.enable_ros2_bridge_extensions()

    # 00 context · 01 clock · 02 cmd_vel · 04 skid-steer · 05 articulation.
    # These come straight from the proven drive graph so /cmd_vel -> wheels and
    # /clock behave identically to the lidar/RTAB-Map runners.
    drive.ensure_ros2_drive_graph(
        robot_prim_path=robot_prim_path,
        graph_path=graph_path,
        ros_domain_id=ros_domain_id,
        cmd_vel_topic=_ns(namespace, drive.DEFAULT_CMD_VEL_TOPIC),  # /cmd_vel
        clock_topic=drive.DEFAULT_CLOCK_TOPIC,                      # /clock (global)
    )

    # 07 odometry + 09 dynamic TF (odom -> base_footprint).
    drive.add_odometry_and_tf(
        robot_prim_path=robot_prim_path,
        graph_path=graph_path,
        odom_topic=_ns(namespace, drive.ODOM_TOPIC),               # /odom
        odom_frame_id=ODOM_FRAME_ID,
        base_frame_id=BASE_FRAME_ID,
    )
    # NOTE: add_odometry_and_tf hard-codes the raw-TF topic to "/tf". Under a
    # namespace, ugv_ws launches remap /tf -> tf inside the namespace, so the raw
    # transform lands on /<ns>/tf as intended — no change needed here.

    # 06 joint states (all six wheels).
    _add_joint_states(robot_prim_path, graph_path, _ns(namespace, "/joint_states"))

    # 10 lidar /scan (+ 11 point cloud) from the baked-in lidar prim.
    lidar_prim = drive.find_lidar_prim(robot_prim_path=robot_prim_path)
    if lidar_prim is not None:
        drive.add_lidar_scan(
            lidar_prim_path=lidar_prim,
            graph_path=graph_path,
            scan_topic=_ns(namespace, drive.SCAN_TOPIC),           # /scan
            frame_id=LIDAR_FRAME_ID,
            show_debug_view=lidar_debug_lines,
        )
        if enable_pointcloud:
            _add_lidar_pointcloud(
                lidar_prim, graph_path, _ns(namespace, "/scan/points"), LIDAR_FRAME_ID
            )

    # 12 RGB + 13 depth camera (/oak/*), reusing the shared OAK-D-Lite emulation.
    if enable_camera:
        camera_prim = drive.find_depth_camera_prim(robot_prim_path=robot_prim_path)
        if camera_prim is not None:
            depthcam.add_depth_camera(
                camera_prim_path=camera_prim,
                graph_path=graph_path,
                rgb_topic=_ns(namespace, depthcam.DEPTH_RGB_TOPIC),
                info_topic=_ns(namespace, depthcam.DEPTH_INFO_TOPIC),
                depth_topic=_ns(namespace, depthcam.DEPTH_DEPTH_TOPIC),
            )

    # 14 IMU (optional; harmless if the rover has no imu prim).
    if enable_imu:
        _add_imu(robot_prim_path, graph_path, _ns(namespace, "/imu/data"), IMU_FRAME_ID)

    # 16 ground truth — THESIS METRICS ONLY. Never feed this into Nav2/SLAM.
    if enable_ground_truth:
        _add_ground_truth_odom(
            robot_prim_path, graph_path, _ns(namespace, "/ground_truth/odom")
        )

    print(
        "[rover_twin] Twin graph built:\n"
        f"  namespace:   {namespace or '(none — plain real-rover names)'}\n"
        f"  robot prim:  {robot_prim_path}\n"
        f"  graph:       {graph_path}\n"
        f"  camera:      {enable_camera}   imu: {enable_imu}   "
        f"pointcloud: {enable_pointcloud}   ground_truth: {enable_ground_truth}"
    )


# ─────────────────────────────────────────────────────────────────────────────
# The graphs that the existing common builders don't cover.
# All attach to the SAME graph_path and reuse its OnPlaybackTick / ROS2Context /
# ReadSimTime nodes (referenced by absolute path), exactly like
# drive.add_odometry_and_tf does.
# ─────────────────────────────────────────────────────────────────────────────

def _add_joint_states(robot_prim_path: str, graph_path: str, topic: str) -> None:
    """06 — publish sensor_msgs/JointState for all six wheels."""
    import omni.graph.core as og
    import usdrt

    keys = og.Controller.Keys
    og.Controller.edit(
        graph_path,
        {
            keys.CREATE_NODES: [
                ("PublishJointState", "isaacsim.ros2.bridge.ROS2PublishJointState"),
            ],
            keys.CONNECT: [
                (f"{graph_path}/OnPlaybackTick.outputs:tick", "PublishJointState.inputs:execIn"),
                (f"{graph_path}/ROS2Context.outputs:context", "PublishJointState.inputs:context"),
                (f"{graph_path}/ReadSimTime.outputs:simulationTime", "PublishJointState.inputs:timeStamp"),
            ],
            keys.SET_VALUES: [
                ("PublishJointState.inputs:targetPrim", [usdrt.Sdf.Path(robot_prim_path)]),
                ("PublishJointState.inputs:topicName", topic),
            ],
        },
    )
    print(f"[rover_twin] Added joint states -> {topic} ({len(ALL_WHEEL_JOINTS)} wheels)")


def _add_lidar_pointcloud(lidar_prim_path: str, graph_path: str, topic: str, frame_id: str) -> None:
    """11 — publish sensor_msgs/PointCloud2 from the RTX lidar (own render product)."""
    import omni.graph.core as og
    import usdrt

    keys = og.Controller.Keys
    og.Controller.edit(
        graph_path,
        {
            keys.CREATE_NODES: [
                ("LidarPointRenderProduct", "isaacsim.core.nodes.IsaacCreateRenderProduct"),
                ("LidarPointHelper", "isaacsim.ros2.bridge.ROS2RtxLidarHelper"),
            ],
            keys.CONNECT: [
                (f"{graph_path}/OnPlaybackTick.outputs:tick", "LidarPointRenderProduct.inputs:execIn"),
                ("LidarPointRenderProduct.outputs:execOut", "LidarPointHelper.inputs:execIn"),
                ("LidarPointRenderProduct.outputs:renderProductPath", "LidarPointHelper.inputs:renderProductPath"),
                (f"{graph_path}/ROS2Context.outputs:context", "LidarPointHelper.inputs:context"),
            ],
            keys.SET_VALUES: [
                ("LidarPointRenderProduct.inputs:cameraPrim", [usdrt.Sdf.Path(lidar_prim_path)]),
                ("LidarPointHelper.inputs:topicName", topic),
                ("LidarPointHelper.inputs:frameId", frame_id),
                ("LidarPointHelper.inputs:type", "point_cloud"),
                ("LidarPointHelper.inputs:resetSimulationTimeOnStop", True),
            ],
        },
    )
    print(f"[rover_twin] Added lidar point cloud -> {topic} (frame {frame_id})")


def _add_imu(robot_prim_path: str, graph_path: str, topic: str, frame_id: str) -> None:
    """14 — read the rover IMU sensor and publish sensor_msgs/Imu.

    Uses the first IMU sensor prim found under the rover; skips cleanly if none
    exists (the lidar/Nav2 stack does not require IMU).
    """
    import omni.usd
    import omni.graph.core as og
    import usdrt

    stage = omni.usd.get_context().get_stage()
    imu_prim = None
    if stage is not None:
        prefix = robot_prim_path.rstrip("/") + "/"
        for p in stage.Traverse():
            path = str(p.GetPath())
            if path != robot_prim_path and not path.startswith(prefix):
                continue
            if "IsaacImuSensor" in str(p.GetTypeName()) or path.lower().endswith("imu"):
                imu_prim = path
                break
    if imu_prim is None:
        print("[rover_twin] No IMU sensor prim found; /imu/data not published.")
        return

    keys = og.Controller.Keys
    og.Controller.edit(
        graph_path,
        {
            keys.CREATE_NODES: [
                ("ReadIMU", "isaacsim.sensors.physics.IsaacReadIMU"),
                ("PublishIMU", "isaacsim.ros2.bridge.ROS2PublishImu"),
            ],
            keys.CONNECT: [
                (f"{graph_path}/OnPlaybackTick.outputs:tick", "ReadIMU.inputs:execIn"),
                ("ReadIMU.outputs:execOut", "PublishIMU.inputs:execIn"),
                (f"{graph_path}/ROS2Context.outputs:context", "PublishIMU.inputs:context"),
                (f"{graph_path}/ReadSimTime.outputs:simulationTime", "PublishIMU.inputs:timeStamp"),
                ("ReadIMU.outputs:linAcc", "PublishIMU.inputs:linearAcceleration"),
                ("ReadIMU.outputs:angVel", "PublishIMU.inputs:angularVelocity"),
                ("ReadIMU.outputs:orientation", "PublishIMU.inputs:orientation"),
            ],
            keys.SET_VALUES: [
                ("ReadIMU.inputs:imuPrim", [usdrt.Sdf.Path(imu_prim)]),
                ("PublishIMU.inputs:topicName", topic),
                ("PublishIMU.inputs:frameId", frame_id),
            ],
        },
    )
    print(f"[rover_twin] Added IMU -> {topic} (frame {frame_id}, prim {imu_prim})")


def _add_ground_truth_odom(robot_prim_path: str, graph_path: str, topic: str) -> None:
    """16 — Isaac world-truth odometry for evaluation. NOT for Nav2/SLAM input."""
    import omni.graph.core as og
    import usdrt

    keys = og.Controller.Keys
    og.Controller.edit(
        graph_path,
        {
            keys.CREATE_NODES: [
                ("GtComputeOdom", "isaacsim.core.nodes.IsaacComputeOdometry"),
                ("GtPublishOdom", "isaacsim.ros2.bridge.ROS2PublishOdometry"),
            ],
            keys.CONNECT: [
                (f"{graph_path}/OnPlaybackTick.outputs:tick", "GtComputeOdom.inputs:execIn"),
                ("GtComputeOdom.outputs:execOut", "GtPublishOdom.inputs:execIn"),
                (f"{graph_path}/ROS2Context.outputs:context", "GtPublishOdom.inputs:context"),
                (f"{graph_path}/ReadSimTime.outputs:simulationTime", "GtPublishOdom.inputs:timeStamp"),
                ("GtComputeOdom.outputs:position", "GtPublishOdom.inputs:position"),
                ("GtComputeOdom.outputs:orientation", "GtPublishOdom.inputs:orientation"),
                ("GtComputeOdom.outputs:linearVelocity", "GtPublishOdom.inputs:linearVelocity"),
                ("GtComputeOdom.outputs:angularVelocity", "GtPublishOdom.inputs:angularVelocity"),
            ],
            keys.SET_VALUES: [
                ("GtComputeOdom.inputs:chassisPrim", [usdrt.Sdf.Path(robot_prim_path)]),
                ("GtPublishOdom.inputs:topicName", topic),
                ("GtPublishOdom.inputs:odomFrameId", "map"),
                ("GtPublishOdom.inputs:chassisFrameId", "base_footprint_gt"),
            ],
        },
    )
    print(f"[rover_twin] Added GROUND TRUTH odom -> {topic} (evaluation only)")
